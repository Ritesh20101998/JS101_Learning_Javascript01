//5. we can use an underscore for declaring a variable 

let first_name = "Ritesh";

let last_name = "Kothawade"

console.log(first_name)

console.log(last_name)

//6. we can use a capital letter for declaring a variable 

let firstName = "Ritesh";

let lastName = "Kothawade"

console.log(firstName)

console.log(lastName)