let a=30;
let b=20;

console.log("my result:",a+a-b);
console.log("my result:",a-b+a);
console.log("my result:",a*b+a);
console.log("my result:",a/b+a);
console.log("my result:",a+b-a*b/a);
