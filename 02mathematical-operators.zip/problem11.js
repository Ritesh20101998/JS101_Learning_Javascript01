
console.log(10%4)//2
console.log(7%2)//1
console.log(6%56)//6
console.log(2%3)//2
console.log(4%4)//0
console.log(56%10)//6
console.log(22%100)//22
console.log(23%20)//3
console.log(23%99)//23
