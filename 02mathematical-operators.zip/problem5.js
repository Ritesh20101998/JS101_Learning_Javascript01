let a=30;
let b=20;
let c=a+b
console.log("Addition is:",c);

c=a-b
console.log("Substraction is:",c);

c=a*b
console.log("Multiplication is:",c);

c=a/b
console.log("Division is:",c);

