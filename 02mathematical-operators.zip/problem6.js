let a=30;
let b=20;

console.log(a+b);
console.log(a-b);
console.log(a*b);
console.log(a/b);

