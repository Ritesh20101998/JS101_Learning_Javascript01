//1. Variable names cannot start with a number

let aman123 = "aman"

console.log(aman123)

let aman23e = "qwerty"

console.log(aman23e)

//2. A variable name cannot start or end with a symbol and underscore

//let x@e = 123

//console.log(x@e)

//except
let $aman ="aman"

let _name = "Chunnu"

console.log($aman)
console.log(_name)