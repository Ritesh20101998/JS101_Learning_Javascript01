let x = 15; //number

let y ="aman"; //string

let X = "13";  //string

console.log(y)