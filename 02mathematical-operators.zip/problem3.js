//3. Variable name should be self-explanatory 

let self_name = "Rahul";

let father_name= "Aman";

let last_name = "Vaidya";

//4. Variable names should not be a keyword

let Var = 10
let Const = 13