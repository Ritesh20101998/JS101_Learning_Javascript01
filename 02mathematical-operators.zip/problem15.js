

first_name = "Ritesh";
middle_name = "Pravin";
last_name = "Kothawade";

console.log(first_name +
" " + middle_name +
" " +last_name)