let X ="10"
let Y ="20"

console.log(X + Y)//1020

X ="10"
Y ="20"

console.log(X +" "+ Y)//10 20

console.log(X +","+ Y)//10,20

console.log(X +"/"+ Y)//10/20