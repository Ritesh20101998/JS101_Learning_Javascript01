x=7
y=3
console.log(x%y)//1

x=3
y=1
console.log(x%y)//0

x=2
y=2
console.log(x%y)//0

x=5
y=2
console.log(x%y)//1

x=6
y=10
console.log(x%y)//6

x=3
y=99
console.log(x%y)//3

x=3
y=9
console.log(x%y)//3