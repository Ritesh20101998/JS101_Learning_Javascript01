let x=18
let y=5
console.log(x%y)//3

x=1
y=5
console.log(x%y)//1

x=1123456
y=5524
console.log(x%y)//2084

x=987654321
y=123456
console.log(x%y)//6321

x=9876
y=987
console.log(x%y)//6

x=987654321
y=0
console.log(x%y)//NaN

x=987654321
y=1
console.log(x%y)//0