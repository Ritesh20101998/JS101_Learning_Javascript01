//Exponentiation operator

console.log(4**2)//16

console.log(3**3)//27

console.log(2**4)//16

console.log(45**2)//2025

console.log(25**3)//15625

console.log(10**10)//10000000000

