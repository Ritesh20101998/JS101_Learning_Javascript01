let x= 10
let y="20"
console.log(x+y)//1020

z=30
console.log(x+y+z)//102030

console.log(x+z+y)//4020

console.log(z+y+z)//302030

console.log(x+x+z)//50

//in shell strings print in white color

//in shell numbers print in brown color