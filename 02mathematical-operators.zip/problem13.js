//calc square root of x

let x=16

console.log(x**.5)//4

console.log(x**(1/2))//4

console.log(3**(1/2))//1.73

console.log(7**(1/3))//2.64575

console.log(36**(1/2))//6

console.log(100**(1/3))//4.64

console.log(1234**(1/24))//1.345