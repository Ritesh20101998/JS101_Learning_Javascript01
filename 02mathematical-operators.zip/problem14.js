//Concatenation

let first_name = "Chunnu";
let last_name = "Kumar";

console.log(first_name +
" " +last_name)

first_name = "Ritesh";
last_name = "Kothawade";

console.log(first_name +
" " +last_name)


first_name = "Siddhesh";
last_name = "Kothawade";

console.log(first_name +
" " +last_name)

first_name = "Harshal";
last_name = "Kothawade";

console.log(first_name +
" " +last_name)