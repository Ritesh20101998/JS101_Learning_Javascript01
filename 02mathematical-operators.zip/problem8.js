//Input
let a=3; 
let b=2;

//Output
// sum is 5
// sub is 1
// mult is 6
// div is 1.5

console.log("sum is ",a+b)
console.log("sub is ",a-b)
console.log("mult is ",a*b)
console.log("div is ",a/b)