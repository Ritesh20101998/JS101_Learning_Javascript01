// Problem 4
// Store the name, school, grade, section, roll and the marks scored by the student in 3 subjects
// Print the report card of the student (You can make it look nice by using some keyboard symbols )
// Explore ASCII ART (https://en.wikipedia.org/wiki/ASCII_art (Links to an external site.)) or Text Art (https://fsymbols.com/text-art/ (Links to an external site.)) for some inspiration

var r = "              ";
var x = "───▄▀▀▀▄▄▄▄▄▄▄▀▀▀▄───";
var y = "───█▒▒░░░░░░░░░▒▒█───";
var z = "────█░░█░░░░░█░░█────";
var a = "─▄▄──█░░░▀█▀░░░█──▄▄─";
var b = "█░░█─▀▄░░░░░░░▄▀─█░░█";
var c = "█▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█";
var d = "█░░╦─╦╔╗╦─╔╗╔╗╔╦╗╔╗░░█";
var e = "█░░║║║╠─║─║─║║║║║╠─░░█";
var f = "█░░╚╩╝╚╝╚╝╚╝╚╝╩─╩╚╝░░█";
var g = "█▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█";
var p = "              ";
const name = "Name: Ritesh Kothawade";
const school = "School Name : Z.P.K.V. Malegaon";
let grade = "Grade : 8";
let section = "Section : B";
let rollno = "Rollno : 26";
var Marathi = "Marathi : 89";
var Hindi = "Hindi : 86";
var English = "English : 96";

console.log(r);
console.log(x);
console.log(y);
console.log(z);
console.log(a);
console.log(b);
console.log(c);
console.log(d);
console.log(e);
console.log(f);
console.log(g);
console.log(p);
console.log("**********REPORT CARD**********");
console.log("                               ");
console.log(name); 
console.log(school); 
console.log(grade); 
console.log(section); 
console.log(rollno); 
console.log(Marathi); 
console.log(Hindi); 
console.log(English);
console.log("                               ");
console.log("**********THANK YOU************");

