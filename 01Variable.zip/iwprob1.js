// Problem 1
// Print "Masai School" in the console followed by "A Transformation in Education" in next line

var x ="Masai School";
var y ="A Trasformation in Education";

console.log(x);
console.log(y);