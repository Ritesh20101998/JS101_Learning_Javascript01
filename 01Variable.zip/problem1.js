// variable is an empty location where we can store anything and name that location variable

//let is used to declare a variable

let x = 12;

//Datatypes:- string, number, bool, bigInt, undefined, null, object, symbol