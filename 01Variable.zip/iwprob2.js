// Problem 2
// Define a variable called name with your Name as the assigned value
// Print the value stored in the variable name
// Change the variable to store your father's name
// Print the value stored in the variable name
// Change the variable again to store your mother's name.
// Print the value stored in the variable name

var self_name = "Ritesh Kothawade";

console.log(self_name);

var father_name = "Pravin Kothawade";

console.log(father_name);

mother_name = "Nalini Kothawade";

console.log(mother_name);