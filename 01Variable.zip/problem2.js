let name = "aman";

console.log(name)

console.log(typeof(name))

let x = 13

console.log(x)

console.log(typeof(x))