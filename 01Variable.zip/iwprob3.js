// Problem 3
// Create a variable name to store your name
// Create a variable age to store your age
// Print the values stored in the variable on one line followed by the type of the variable in the next line

var name ="Ritesh";
var age = "23";

console.log(name,age);
console.log(typeof(name,age));
