//let
let x = 12;
console.log(x)

let y=11
y=113
y=15
y=115
Y=12
console.log(y)
let z = 12

z=13

console.log(z)

// var
var a = 123
a=1234
console.log(a)
var b = 12
console.log(b)

c = 34
console.log(c)

//const
const ab = 543
console.log(ab)